"""基准夹具用的小包：报告自己装在哪个环境里。"""

import os
import sys

__version__ = "1.0.0"


def banner():
    return f"hello-bench {__version__} prefix={os.path.basename(sys.prefix)}"


def main():
    print(banner())
